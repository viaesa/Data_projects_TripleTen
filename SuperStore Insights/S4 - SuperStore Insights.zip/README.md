# Tableau Public Project - Returns Analysis

## Overview
This project analyzes return rates by product and customer, along with the relationship between profit and return rate.

## Tableau Public Link
[Click here to view the Tableau workbook](https://public.tableau.com/app/profile/victoria.angulo.espinosa/viz/TT-S4Project/SummaryofReturnRates?publish=yes)

## Files Included
- **Workbook (.twbx or .twb)** – Tableau project file  
- **Data files** – Any necessary CSV/Excel files  
- **README.md** – This file  

## How to Use
1. Open the Tableau workbook in Tableau Public or Desktop.  
2. Explore different sheets and dashboards for insights.  

## Author
Victoria Angulo
